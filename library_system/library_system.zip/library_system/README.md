# django-accounts
a simple Django Project for dealing with user auth
